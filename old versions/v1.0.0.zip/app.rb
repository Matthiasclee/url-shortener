require "sinatra"
get("/") do
	erb :home
end
get("/resources/:r") do
	send_file "./resources/" + params["r"]
end
get("/adminpanel") do
@error = ""
erb :adminsignin
end
post("/adminpanel") do
if params["pass"] == File.read("./adminpassword.txt").gsub("\n", "")
	@vlg = File.read("./VIEW LOG.txt").gsub("\n", "<br>")
	@clg = File.read("./CREATION LOG.txt").gsub("\n", "<br>")
	erb :admin
else
	@error = "<p style = 'color:red'>Invalid Password</p>"
	erb :adminsignin
end
end
post("/") do
	if params["csturl"].gsub(" ", "") == ""
		uw = Hash[*File.read('uw.txt').split(/[, \n]+/)]
		wu = Hash[*File.read('wu.txt').split(/[, \n]+/)]
		uw_custom = Hash[*File.read('uw_custom.txt').split(/[, \n]+/)]
		uch = ["a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z", "1", "2", "3", "4", "5", "6", "7", "8", "9", "0", "@", "_", "-"]
		outurl = nil
		if wu[params["url"].gsub(" ", "")] != nil
			File.write("CREATION LOG.txt", "\n#{wu[params["url"].gsub(" ", "")]} Recreated on #{Time.now.inspect} by #{request.ip}", mode: "a")
			outurl = wu[params["url"].gsub(" ", "")]
			@ou = outurl
				erb :done
		else
			rdu = params["url"].gsub(" ", "")
			if rdu[0..7] == "https://" || rdu[0..6] == "http://" || rdu[0..5] == "ftp://"
			else
				rdu = "http://" + rdu
			end
			outurl = "#{uch[rand(1..37) - 1]}" + "#{uch[rand(1..37) - 1]}" + "#{uch[rand(1..37) - 1]}" + "#{uch[rand(1..37) - 1]}" + "#{uch[rand(1..37) - 1]}"
			if uw_custom[outurl] != nil || uw[outurl] != nil
				return "An internal error has occured. Please go back and try again."
			else
				File.write("uw.txt", "\n#{outurl}, #{rdu}", mode: "a")
				File.write("wu.txt", "\n#{rdu}, #{outurl}", mode: "a")
				File.write("CREATION LOG.txt", "\n#{outurl} Created on #{Time.now.inspect} by #{request.ip}", mode: "a")
				@ou = outurl
				erb :done
			end
		end
	else
		uw = Hash[*File.read('uw.txt').split(/[, \n]+/)]
		wu = Hash[*File.read('wu.txt').split(/[, \n]+/)]
		uw_custom = Hash[*File.read('uw_custom.txt').split(/[, \n]+/)]
		outurl = nil
		if uw[params["csturl"].gsub(" ", "")] != nil || uw_custom[params["csturl"].gsub(" ", "")] != nil
			erb :exists
		else
			rdu = params["url"].gsub(" ", "")
			if rdu[0..7] == "https://" || rdu[0..6] == "http://" || rdu[0..5] == "ftp://"
			else
				rdu = "http://" + rdu
			end
			outurl = params["csturl"].gsub(" ", "")
			if !!outurl.match(/[^A-z0-9_\-\@]/) || outurl.include?("\\")
				erb :badchar
			else
				File.write("uw_custom.txt", "\n#{outurl}, #{rdu}", mode: "a")
				File.write("CREATION LOG.txt", "\n#{outurl} Created on #{Time.now.inspect} by #{request.ip}", mode: "a")
				@ou = outurl
				erb :done
			end
		end
	end
end
post("/api") do
	if params["csturl"].gsub(" ", "") == ""
		uw = Hash[*File.read('uw.txt').split(/[, \n]+/)]
		wu = Hash[*File.read('wu.txt').split(/[, \n]+/)]
		uw_custom = Hash[*File.read('uw_custom.txt').split(/[, \n]+/)]
		uch = ["a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z", "1", "2", "3", "4", "5", "6", "7", "8", "9", "0", "@", "_", "-"]
		outurl = nil
		if wu[params["url"].gsub(" ", "")] != nil
			File.write("CREATION LOG.txt", "\n#{wu[params["url"].gsub(" ", "")]} Recreated on #{Time.now.inspect} by #{request.ip} with API", mode: "a")
			outurl = wu[params["url"].gsub(" ", "")]
				return outurl
		else
			rdu = params["url"].gsub(" ", "")
			if rdu[0..7] == "https://" || rdu[0..6] == "http://" || rdu[0..5] == "ftp://"
			else
				rdu = "http://" + rdu
			end
			outurl = "#{uch[rand(1..37) - 1]}" + "#{uch[rand(1..37) - 1]}" + "#{uch[rand(1..37) - 1]}" + "#{uch[rand(1..37) - 1]}" + "#{uch[rand(1..37) - 1]}"
			if uw_custom[outurl] != nil || uw[outurl] != nil
				return "An internal error has occured. Please go back and try again."
			else
				File.write("uw.txt", "\n#{outurl}, #{rdu}", mode: "a")
				File.write("wu.txt", "\n#{rdu}, #{outurl}", mode: "a")
				File.write("CREATION LOG.txt", "\n#{outurl} Created on #{Time.now.inspect} by #{request.ip} with API", mode: "a")
				return outurl
			end
		end
	else
		uw = Hash[*File.read('uw.txt').split(/[, \n]+/)]
		wu = Hash[*File.read('wu.txt').split(/[, \n]+/)]
		uw_custom = Hash[*File.read('uw_custom.txt').split(/[, \n]+/)]
		outurl = nil
		if uw[params["csturl"].gsub(" ", "")] != nil || uw_custom[params["csturl"].gsub(" ", "")] != nil
			return "ERR:URLEXIST"
		else
			rdu = params["url"].gsub(" ", "")
			if rdu[0..7] == "https://" || rdu[0..6] == "http://" || rdu[0..5] == "ftp://"
			else
				rdu = "http://" + rdu
			end
			outurl = params["csturl"].gsub(" ", "")
			if !!outurl.match(/[^A-z0-9_\-\@]/) || outurl.include?("\\")
				return "ERR:BADCHAR"
			else
				File.write("uw_custom.txt", "\n#{outurl}, #{rdu}", mode: "a")
				File.write("CREATION LOG.txt", "\n#{outurl} Created on #{Time.now.inspect} by #{request.ip} with API", mode: "a")
				return outurl
			end
		end
	end
end
get("/:url") do
	if Hash[*File.read('uw.txt').split(/[, \n]+/)][params["url"]] != nil
		File.write("./VIEW LOG.txt", "\n#{params["url"]} Viewed on #{Time.now.inspect} by #{request.ip}", mode: "a")
		redirect Hash[*File.read('uw.txt').split(/[, \n]+/)][params["url"]]
	else
		
		if Hash[*File.read('uw_custom.txt').split(/[, \n]+/)][params["url"]] != nil
			File.write("./VIEW LOG.txt", "\n#{params["url"]} viewed on #{Time.now.inspect} by #{request.ip}", mode: "a")
			redirect Hash[*File.read('uw_custom.txt').split(/[, \n]+/)][params["url"]]
		else
			erb :notfound
		end
	end
end
get("/preview/:url") do
	if Hash[*File.read('uw.txt').split(/[, \n]+/)][params["url"]] != nil
		@url = Hash[*File.read('uw.txt').split(/[, \n]+/)][params["url"]]
		erb :preview
	else
		if Hash[*File.read('uw_custom.txt').split(/[, \n]+/)][params["url"]] != nil
			@url = Hash[*File.read('uw_custom.txt').split(/[, \n]+/)][params["url"]]
			erb :preview
		else
			erb :notfound
		end
	end
end

require "sinatra"
get("/") do
	erb :home
end
get("/resources/:r") do
	send_file "./resources/" + params["r"]
end
get("/adminpanel") do
@error = ""
erb :adminsignin
end
post("/adminpanel") do
if params["pass"] == File.read("./adminpassword.txt")
	erb :admin
else
	@error = "<p style = 'color:red'>Invalid Password</p>"
	erb :adminsignin
end
end
post("/") do
	uw = Hash[*File.read('uw.txt').split(/[, \n]+/)]
	wu = Hash[*File.read('wu.txt').split(/[, \n]+/)]
	uch = ["a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z", "1", "2", "3", "4", "5", "6", "7", "8", "9", "0", "@"]
	outurl = nil
	if wu[params["url"]] != nil
		File.write("CREATION LOG.txt", "\n#{wu[params["url"]]} Recreated on #{Time.now.inspect} by #{request.ip}", mode: "a")
		outurl = wu[params["url"]]
	else
		rdu = params["url"]
		if rdu[0..7] == "https://" || rdu[0..6] == "http://" || rdu[0..5] == "ftp://"
		else
			rdu = "http://" + rdu
		end
		outurl = "#{uch[rand(1..37) - 1]}" + "#{uch[rand(1..37) - 1]}" + "#{uch[rand(1..37) - 1]}" + "#{uch[rand(1..37) - 1]}" + "#{uch[rand(1..37) - 1]}"
		File.write("uw.txt", "\n#{outurl}, #{rdu}", mode: "a")
		File.write("wu.txt", "\n#{rdu}, #{outurl}", mode: "a")
		File.write("CREATION LOG.txt", "\n#{outurl} Created on #{Time.now.inspect} by #{request.ip}", mode: "a")
	end
	@ou = outurl
	erb :done
end
get("/:url") do
	if Hash[*File.read('uw.txt').split(/[, \n]+/)][params["url"]] != nil
		File.write("./VIEW LOG.txt", "\n#{params["url"]} Viewed on #{Time.now.inspect} by #{request.ip}", mode: "a")
		redirect Hash[*File.read('uw.txt').split(/[, \n]+/)][params["url"]]
	else
		File.write("./VIEW LOG.txt", "\n#{params["url"]} Attempted to be viewed on #{Time.now.inspect} by #{request.ip}", mode: "a")
		erb :notfound
	end
end
